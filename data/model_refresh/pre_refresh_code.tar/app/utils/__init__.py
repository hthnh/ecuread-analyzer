"""Small utility helpers."""

